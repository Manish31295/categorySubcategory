const express = require("express");
const app = express();
const  mongoose  = require("mongoose");
const bodyParser = require("body-parser");
const port = process.env.PORT || '4000';
const productRouter = require("./routes/product")

mongoose.connect("mongodb://localhost:27017/subcat", { useNewUrlParser: true, useUnifiedTopology: true })
mongoose.connection.on("connected", connected=>console.log(`connected to database`))
mongoose.connection.once("unconnected", unconnected=>console.log(`not connected to database`))

app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());
app.use(productRouter)


app.listen(port, ()=>{
    console.log(`server running on http://localhost:${port}`);
})