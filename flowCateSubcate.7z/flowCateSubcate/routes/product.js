const express = require("express");
const router = express.Router();
const Product = require("../model/product");


router.post('/products', (req, res, next)=>{

    try{
        const productDoc =  new Product({
            title:req.body.title,
            description:req.body.description,
            qty:req.body.qty,
            price:req.body.price,
            category:req.body.category

        })
        productDoc.save()
        .then(prod=>{
            res.status(200).json({
                message:"add to successfully",
                prod
            })
        })
        
    }
    catch(error){
        throw error
    }
})

module.exports = router;